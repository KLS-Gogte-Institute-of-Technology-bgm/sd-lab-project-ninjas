-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2020 at 04:30 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `reserve`
--

CREATE TABLE `reserve` (
  `id` int(11) NOT NULL,
  `firstName` varchar(256) NOT NULL,
  `date` date NOT NULL,
  `date1` date NOT NULL,
  `gender` varchar(256) NOT NULL,
  `gender1` varchar(256) NOT NULL,
  `gender2` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reserve`
--

INSERT INTO `reserve` (`id`, `firstName`, `date`, `date1`, `gender`, `gender1`, `gender2`) VALUES
(0, 'Shubham', '2020-12-25', '2020-12-25', 'on', 'on', 'on'),
(0, 'Chetan', '2020-12-25', '2020-12-29', 'on', 'on', 'on'),
(0, 'Arvind', '2020-12-25', '2020-12-29', 'on', 'on', 'on'),
(0, 'Arvind', '2020-12-27', '2020-12-30', 'on', 'on', 'on'),
(0, 'Abhi', '2020-12-27', '2020-12-30', 'on', 'on', 'on'),
(0, 'Aditya', '2020-12-27', '2020-12-29', 'on', 'on', 'on'),
(0, 'Chetan', '2020-12-27', '2020-12-29', 'on', 'on', 'on'),
(0, 'Aditya', '2020-12-25', '2020-12-27', 'on', 'on', 'on'),
(0, 'Abhi', '2020-12-25', '2020-12-27', 'on', 'on', 'on'),
(0, 'aditya', '2020-12-27', '2020-12-30', 'on', 'on', 'on'),
(0, 'arun', '2020-12-27', '2020-12-30', 'on', 'on', 'on'),
(0, 'Arvind', '2020-12-27', '2020-12-29', 'on', 'on', 'on');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
